CKEDITOR.replace( 'editor', {
	filebrowserBrowseUrl: 'assets/plugins/ckfinder/ckfinder.html',
	filebrowserUploadUrl: 'assets/plugins/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files'
});